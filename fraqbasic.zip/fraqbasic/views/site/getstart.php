<div class="row">
    <div class="col-lg-4 col-md-4">
        <a href="#" class="thumbnail  homesquare">
            <i class="material-icons">people</i>
        </a>
        
    </div>
    <div class="col-lg-4 col-md-4 ">
        <a href="#" class="thumbnail  homesquare">
             <i class="material-icons">group</i>
        </a>
        
    </div>
    <div class="col-lg-4 col-md-4 ">
        <a href="#" class="thumbnail  homesquare">
             <i class="material-icons">people_outline</i>
        </a>
    </div>
</div>
<div class="row">
    <div class="col-lg-4 col-md-4">
        <a href="#" class="thumbnail  homesquare">
            <i class="glyphicon  glyphicon-picture"></i>
        </a>
        
    </div>
    <div class="col-lg-4 col-md-4 ">
        <a href="#" class="thumbnail  homesquare">
            <i class="glyphicon  glyphicon-music"></i>
        </a>
        
    </div>
    <div class="col-lg-4 col-md-4 ">
        <a href="#" class="thumbnail  homesquare">
            <i class="glyphicon  glyphicon-film"></i>
        </a>
    </div>
</div>

<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

